package com.demo.Springsecuritydemo1baseApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringSecurityDemo1BaseAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
